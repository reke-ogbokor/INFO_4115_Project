# kotlin-rotary-knob
Rotary knob view for Android, written in Kotlin

This project accompanies the article I published on medium - 
https://medium.com/swlh/creating-a-kotlin-android-rotary-knob-b3a16d02e346

Licensed under Apache 2.0 license.
